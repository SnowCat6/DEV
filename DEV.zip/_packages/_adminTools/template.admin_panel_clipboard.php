<? function admin_panel_clipboard(&$val, &$data){
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="33%"><h2 class="ui-state-default">Документы</h2></td>
    <td width="33%"><h2 class="ui-state-default">Файлы</h2></td>
    <td width="33%"><h2 class="ui-state-default">Текст</h2></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

<? return "Clipboard" ;} ?>