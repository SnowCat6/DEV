<?
addEvent('site.fullPageCache',	'fullpageCache');
addEvent('cache.clear', 		'fullPageCacheClear');
?>