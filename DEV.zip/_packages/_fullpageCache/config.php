<?
addEvent('site.getPageCacheName',	'fullpageCache');
?>