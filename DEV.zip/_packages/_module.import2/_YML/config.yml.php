<?
addUrl('yandex-xml',	'import:YandexXML:direct');
addUrl('yandex-export',	'import:YandexXML:page');
?>