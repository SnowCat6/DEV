<?
addEvent('import.source', 	'import:txtSource');
addEvent('import.synch', 	'import:txtSynch');
addEvent('import.cancel', 	'import:txtCancel');
addEvent('import.delete', 	'import:txtDelete');

addUrl('import_txtSettings','import:txtSettings');
?>