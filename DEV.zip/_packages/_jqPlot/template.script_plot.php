<? function script_plot($val){ m('script:jq_ui'); ?>
<link rel="stylesheet" type="text/css" href="script/jqPlot/jquery.jqplot.min.css"/>
<script type="text/javascript" src="script/jqPlot/jquery.jqplot.min.js"></script>
<script type="text/javascript" src="script/jqPlot/plugins/jqplot.dateAxisRenderer.min.js"></script>
<? } ?>
<? function style_plot($val){?>
<style>
.jqplot-table-legend{
	color:black;
	font-size:1.2em;
}
</style>
<? } ?>