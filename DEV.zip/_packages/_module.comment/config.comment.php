<?
addEvent('document.comment', 'doc:comment');
?>