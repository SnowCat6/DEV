<?
addUrl('tools_mail',	'tools:mail');
?>