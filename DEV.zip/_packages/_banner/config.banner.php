<?
addUrl('banner_edit_([a-z\d]+)', 'banner:edit');
?>