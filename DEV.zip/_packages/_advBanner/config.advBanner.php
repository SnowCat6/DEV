<?
addUrl('advBanner',	'advBannerEdit');
?>