<?
addUrl('layout_admin',	'layout:admin');
addUrl('layout_update',	'layout:update');

addEvent('admin.tools.edit','layout:tools');
addEvent('site.header',		'layout:render');
?>