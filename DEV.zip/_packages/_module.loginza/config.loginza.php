<?
addUrl('loginza_login',	'loginza:login');
?>