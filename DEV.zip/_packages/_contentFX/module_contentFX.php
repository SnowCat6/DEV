<? function module_contentFX($val, $data)
{
	m('script:jq');
	m('styleLoad',	'css/contentFX.css');
	m('scriptLoad',	'script/contentFX.js');
?>
<? } ?>