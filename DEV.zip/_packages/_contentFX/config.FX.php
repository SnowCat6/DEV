<?
addEvent('site.header',	'contentFX');
?>