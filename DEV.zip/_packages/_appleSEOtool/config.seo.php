<?
addEvent('site.initialize',	'appleSEOtools');
?>