<?
addEvent('document.gallery',	'doc:gallery');
addSnippet('gallery', 			'{{doc:gallery}}');
addUrl("gallery_adminImageMask(\d+)",		'gallery:adminImageMask');
?>