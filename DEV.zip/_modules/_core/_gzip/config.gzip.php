<?
	addEvent('site.close', 'gzip');
?>