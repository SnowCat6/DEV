﻿<?
addEvent('site.render',	'siteRender');
addEvent('site.end',	'siteRenderEnd');
?>