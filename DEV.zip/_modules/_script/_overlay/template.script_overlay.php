<? function script_overlay($val)
{
	m('script:jq');
	m('fileLoad', 'script/jQuery.overlay.js');
} ?>
