﻿<? function script_fileUpload()
{
	m('script:jq');
	m('scriptLoad', 'script/fileUpload.js');
 } ?>
