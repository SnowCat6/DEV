﻿<?
addUrl('file_images_get',			'fileUpload:get');
addUrl('file_images_upload',		'fileUpload:upload');
addUrl('file_images_delete',		'fileUpload:delete');
addUrl('file_images_comment/(.+)',	'file:comment');
addUrl('file_images_delete/(.+)',	'file:delete');
?>