﻿<? function script_ajaxForm($val){
	m('script:overlay');
	m('fileLoad', 'css/core.css');
	m('scriptLoad', 'script/ajaxForm.js');
} ?>
