﻿<? function script_ajaxLink($val)
{
	m('script:overlay');
	m('fileLoad', 'script/jQuery.ajaxLink.js');
	m('page:style', 'css/ajax.css');
} ?>
