﻿<? function script_clone($val){?>
<? module('script:jq')?>
<script src="script/ajax.adminClone.js"></script>
<? } ?>
