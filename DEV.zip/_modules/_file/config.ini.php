<?
addEvent('storage.get',	'file:storage:get');
addEvent('storage.set',	'file:storage:set');
?>