<?
addUrl('file_imageMaskUpload', 	'file:imageMaskUpload');
?>