<? function script_preview($val)
{
	m('script:jq');
	m('fileLoad',	'css/jqPreview.css');
	m('fileLoad',	'script/jqPreview.js');
}
?>
