<?
addUrl('preview_(.+)',	'preview:page');
?>