<?
function doc_read_menuLink_beginCache(&$db, $val, &$search){
	$search['currentPage']	= currentPage();
	return	 hashData($search);
}

function doc_read_menuLink(&$db, $val, &$search)
{
	$split = ' id="first"';
	while($data = $db->next()){
		$id		= $db->id();
		$url	= getURL($db->url());
		$class	= currentPage() == $id?'current':'';
		@$fields	= $data['fields'];
		if (@$c	= $fields['class']) $class .= " $c";
		if ($class) $class = " class=\"$class\"";
?>
<a href="{$url}" {!$split} title="{$data[title]}"{!$class}>{$data[title]}</a>
<? $split = ''; } ?>
<? return $search; } ?>